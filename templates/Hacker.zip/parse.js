// 解析列表脚本
temp = $HTML.split('<article>');
temp.shift();
var result = [];
temp.map(function (tmp) {
  var title = tmp.split('<span>')[1].split('<')[0];
  var href = tmp.split('<a href="')[1].split('"')[0];
  var date = tmp.split('datetime="')[1].split('T')[0];
  var desc = tmp.split('class="entry">')[1].split('</div>')[0];
  var tag = tmp.split('tags"></i>')[1].split('">')[1].split('<')[0];
  result.push({
    title: title,
    link: '$WEB_SITE$' + href,
    description: desc.replace(/<\/?.+?>/g, '').trim(),
    tags: [{ icon: 'ios-calendar', text: date }],
    category: [tag]
  });
});
return result;